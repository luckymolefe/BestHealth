<?php
	//Database login credentials

	$config = array(
		'host'=> 'localhost',
		'username'=> 'webusers',
		'password'=> 'edecobode',
		'dbname'=> 'besthealth',
		'PORT'=> '3306'
	);

?>